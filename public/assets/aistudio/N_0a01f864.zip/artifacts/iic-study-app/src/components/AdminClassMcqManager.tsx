// @ts-nocheck
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Save, Trash2, ChevronRight, ArrowLeft, Plus, BookOpen, Edit2, X, ArrowRight, Copy, Library } from 'lucide-react';
import { parseMCQText, normalizeMcqPaste } from '../utils/mcqParser';
import { saveMcqLesson, deleteMcqLesson, subscribeMcqLessons } from '../firebase';
import { getLucentSubjectOptions, LUCENT_SUBJECT_OPTIONS_BASE, getClassSubjectOptions } from '../constants';

const CLASSES = ['6', '7', '8', '9', '10', '11', '12', 'COMPETITION'];

const DEFAULT_CLASS_SUBJECTS: Record<string, string[]> = {
  '6': ['Science', 'Mathematics', 'Social Science', 'Hindi', 'English', 'Sanskrit'],
  '7': ['Science', 'Mathematics', 'Social Science', 'Hindi', 'English', 'Sanskrit'],
  '8': ['Science', 'Mathematics', 'Social Science', 'Hindi', 'English', 'Sanskrit'],
  '9': ['Science', 'Mathematics', 'Social Science', 'Hindi', 'English', 'Sanskrit'],
  '10': ['Science', 'Mathematics', 'Social Science', 'Hindi', 'English', 'Sanskrit'],
  '11': ['Physics', 'Chemistry', 'Biology', 'Mathematics', 'Hindi', 'English', 'History', 'Geography', 'Economics', 'Political Science'],
  '12': ['Physics', 'Chemistry', 'Biology', 'Mathematics', 'Hindi', 'English', 'History', 'Geography', 'Economics', 'Political Science'],
  'COMPETITION': ['General Knowledge', 'General Science', 'Mathematics', 'Reasoning', 'Current Affairs', 'Hindi', 'English'],
};

function subjectsForClass(cls: string, settings?: any): string[] {
  const fromSettings = settings?.syllabusConfig?.[cls]?.subjects || settings?.classSubjects?.[cls];
  if (Array.isArray(fromSettings) && fromSettings.length > 0) {
    return fromSettings;
  }
  return DEFAULT_CLASS_SUBJECTS[cls] || ['Science', 'Mathematics', 'Social Science', 'Hindi', 'English'];
}

interface Props {
  settings: any;
  onSave: (key: string, mcqs: any[]) => void;
}

type Screen = 'CLASS' | 'SUBJECT' | 'LESSON_LIST' | 'ADD_LESSON';

const BOARD_OPTIONS = [
  { id: '' as const,         label: '🌐 All',       desc: 'All Boards' },
  { id: 'NCERT_EN' as const, label: '📘 NCERT EN',  desc: 'English medium' },
  { id: 'NCERT_HI' as const, label: '📙 NCERT HI',  desc: 'Hindi medium' },
  { id: 'BSEB' as const,     label: '🟠 BSEB',      desc: 'Bihar board' },
];

export const AdminClassMcqManager: React.FC<Props> = ({ settings, onSave }) => {
  const [screen, setScreen]               = useState<Screen>('CLASS');
  const [selectedClass, setSelectedClass] = useState<string | null>(null);
  const [selectedSubject, setSelectedSubject] = useState<string | null>(null);
  const [allLessons, setAllLessons]       = useState<any[]>([]);
  const [editingLesson, setEditingLesson] = useState<any | null>(null);
  const [boardFilter, setBoardFilter]     = useState<'' | 'NCERT_EN' | 'NCERT_HI' | 'BSEB'>('');

  // Add lesson form state
  const [lessonTitle, setLessonTitle] = useState('');
  const [bookName, setBookName]       = useState('');
  const [pasteText, setPasteText]     = useState('');
  const [saving, setSaving]           = useState(false);
  const [alert, setAlert]             = useState('');

  // Move/Copy modal state
  const [moveCopyModal, setMoveCopyModal] = useState<{ lesson: any; mode: 'move' | 'copy' } | null>(null);
  const [mcTargetClass, setMcTargetClass] = useState<string>('6');
  const [mcTargetSubject, setMcTargetSubject] = useState<string>('');
  const [mcTargetBoard, setMcTargetBoard] = useState<'' | 'NCERT_EN' | 'NCERT_HI' | 'BSEB'>('');
  const [mcWorking, setMcWorking] = useState(false);

  const showAlert = (msg: string) => { setAlert(msg); setTimeout(() => setAlert(''), 4000); };

  // Subscribe to mcq_lessons from Firebase
  useEffect(() => {
    const unsub = subscribeMcqLessons((lessons) => setAllLessons(lessons));
    return unsub;
  }, []);

  // Subject list for current class: combines standard syllabus subjects + any subjects from saved lessons/notes
  const subjectsList = useMemo(() => {
    if (!selectedClass) return [];
    const base = subjectsForClass(selectedClass, settings);
    const seen = new Set(base.map(s => s.trim().toLowerCase()));
    const extra: string[] = [];
    allLessons
      .filter(l => l.classLevel === selectedClass && l.subject)
      .forEach(l => {
        const s = String(l.subject).trim();
        if (s && !seen.has(s.toLowerCase())) {
          seen.add(s.toLowerCase());
          extra.push(s);
        }
      });
    return [...base, ...extra];
  }, [selectedClass, settings, allLessons]);

  // Auto-sync: if settings.lucentNotes has lessons not in allLessons, auto-sync them!
  const autoSyncDoneRef = useRef(false);
  useEffect(() => {
    if (autoSyncDoneRef.current) return;
    const lucentNotes: any[] = settings?.lucentNotes || [];
    if (!lucentNotes.length) return;
    const existingTitles = new Set(allLessons.map(l => String(l.lessonTitle || '').trim().toLowerCase()));
    const missing = lucentNotes.filter(n => n?.lessonTitle?.trim() && !existingTitles.has(n.lessonTitle.trim().toLowerCase()));
    if (missing.length > 0) {
      autoSyncDoneRef.current = true;
      console.log(`[AdminClassMcqManager] Found ${missing.length} unsynced notes, auto-syncing to mcq_lessons...`);
      (async () => {
        for (const n of missing) {
          try {
            const cls = (n.classLevel && String(n.classLevel).trim() && String(n.classLevel).trim() !== 'ALL') ? String(n.classLevel).trim() : 'COMPETITION';
            let subjName = n.subject;
            if (cls === 'COMPETITION') {
              const opt = getLucentSubjectOptions(settings).find(o => o.id === n.subject || o.name.trim().toLowerCase() === n.subject.trim().toLowerCase());
              subjName = opt?.name || LUCENT_SUBJECT_OPTIONS_BASE.find(o => o.id === n.subject)?.name || n.subject;
            } else {
              const opt = getClassSubjectOptions(cls).find(o => o.id === n.subject || o.name.trim().toLowerCase() === n.subject.trim().toLowerCase());
              subjName = opt?.name || n.subject;
            }
            const isTopicMcq = (m: any) => {
              if (!m?.question?.trim()) return false;
              const t = String(m.topic || '').trim().toLowerCase();
              return t !== '' && t !== 'general' && t !== 'सामान्य' && t !== 'general mcq' && t !== 'general mcqs';
            };
            const pageMcqs = (n.pages || []).flatMap((p: any) =>
              (p.mcqs || []).filter(isTopicMcq)
            );
            const topics = [...new Set(pageMcqs.map((q: any) => q.topic).filter(Boolean))] as string[];
            const lesson = {
              id: `clsnotes_${n.id || Date.now()}`,
              classLevel: cls,
              subject: subjName || 'General',
              board: n.board || null,
              bookName: n.bookName || null,
              lessonTitle: n.lessonTitle.trim(),
              mcqs: pageMcqs || [],
              mcqCount: pageMcqs.length,
              topics,
              topicCount: topics.length,
              topicNotes: [],
              createdAt: n.createdAt || new Date().toISOString(),
              updatedAt: new Date().toISOString(),
              sourceClassNotesId: n.id,
            };
            await saveMcqLesson(lesson);
          } catch (e) {
            console.warn('[AdminClassMcqManager] auto-sync note error:', e);
          }
        }
      })();
    }
  }, [allLessons, settings]);

  // Sync all notes from settings.lucentNotes to mcq_lessons manually
  const [syncingAllNotes, setSyncingAllNotes] = useState(false);
  const handleSyncAllNotes = async () => {
    const lucentNotes: any[] = settings?.lucentNotes || [];
    if (!lucentNotes.length) {
      showAlert('ℹ️ Koi Notes nahi mile sync karne ke liye.');
      return;
    }
    setSyncingAllNotes(true);
    let syncedCount = 0;
    try {
      const isTopicMcq = (m: any) => {
        if (!m?.question?.trim()) return false;
        const t = String(m.topic || '').trim().toLowerCase();
        return t !== '' && t !== 'general' && t !== 'सामान्य' && t !== 'general mcq' && t !== 'general mcqs';
      };
      for (const n of lucentNotes) {
        if (!n || !n.lessonTitle || !n.lessonTitle.trim()) continue;
        const cls = (n.classLevel && String(n.classLevel).trim() && String(n.classLevel).trim() !== 'ALL') ? String(n.classLevel).trim() : 'COMPETITION';
        let subjName = n.subject;
        if (cls === 'COMPETITION') {
          const opt = getLucentSubjectOptions(settings).find(o => o.id === n.subject || o.name.trim().toLowerCase() === n.subject.trim().toLowerCase());
          subjName = opt?.name || LUCENT_SUBJECT_OPTIONS_BASE.find(o => o.id === n.subject)?.name || n.subject;
        } else {
          const opt = getClassSubjectOptions(cls).find(o => o.id === n.subject || o.name.trim().toLowerCase() === n.subject.trim().toLowerCase());
          subjName = opt?.name || n.subject;
        }
        const pageMcqs = (n.pages || []).flatMap((p: any) =>
          (p.mcqs || []).filter(isTopicMcq)
        );
        const existing = allLessons.find(l => l.id === `clsnotes_${n.id}` || l.sourceClassNotesId === n.id);
        const rawMcqs = (existing && Array.isArray(existing.mcqs) && existing.mcqs.length > 0)
          ? existing.mcqs
          : pageMcqs;
        const currentMcqs = rawMcqs.filter(isTopicMcq);
        const topics = [...new Set(currentMcqs.map((q: any) => q.topic).filter(Boolean))] as string[];

        const lesson = {
          id: `clsnotes_${n.id || Date.now()}`,
          classLevel: cls,
          subject: subjName || 'General',
          board: n.board || existing?.board || null,
          bookName: n.bookName || existing?.bookName || null,
          lessonTitle: n.lessonTitle.trim(),
          mcqs: currentMcqs || [],
          mcqCount: (currentMcqs || []).length,
          topics,
          topicCount: topics.length,
          topicNotes: existing?.topicNotes || [],
          createdAt: existing?.createdAt || n.createdAt || new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          sourceClassNotesId: n.id,
        };
        await saveMcqLesson(lesson);
        syncedCount++;
      }
      showAlert(`✅ ${syncedCount} notes Revision Hub me sync ho gaye!`);
    } catch (e: any) {
      showAlert(`❌ Sync error: ${e?.message || 'Failed'}`);
    } finally {
      setSyncingAllNotes(false);
    }
  };

  // Lessons filtered for current class+subject+board
  const filteredLessons = allLessons.filter(l => {
    if (l.classLevel !== selectedClass) return false;
    const subMatch = isSubjectMatch(l.subject, selectedSubject, selectedClass, settings);
    if (!subMatch) return false;
    if (boardFilter !== '' && l.board && l.board !== boardFilter) return false;
    return true;
  });

  // Count lessons per subject for subject screen
  const lessonCountForSubject = (cls: string, sub: string) =>
    allLessons.filter(l => {
      if (l.classLevel !== cls) return false;
      const subMatch = isSubjectMatch(l.subject, sub, cls, settings);
      if (!subMatch) return false;
      if (boardFilter !== '' && l.board && l.board !== boardFilter) return false;
      return true;
    }).length;

  // Count total lessons per class for class screen
  const lessonCountForClass = (cls: string) =>
    allLessons.filter(l => l.classLevel === cls && (boardFilter === '' || !l.board || l.board === boardFilter)).length;

  // Reusable board switcher bar
  const BoardBar = (
    <div className="flex gap-1.5 mb-3">
      {BOARD_OPTIONS.map(b => (
        <button key={b.id} type="button"
          onClick={() => setBoardFilter(b.id)}
          className={`flex-1 py-1.5 rounded-xl text-[10px] font-black transition-all border ${
            boardFilter === b.id
              ? 'bg-indigo-600 text-white border-indigo-600 shadow'
              : 'bg-white text-indigo-700 border-indigo-200 hover:border-indigo-400'
          }`}
        >
          {b.label}
        </button>
      ))}
    </div>
  );

  const handleSaveLesson = async () => {
    if (!lessonTitle.trim()) { showAlert('❌ Lesson title daalein'); return; }
    setSaving(true);
    try {
      const raw = pasteText.trim();
      let parsed: any[] = [];
      const notesToSave: { title: string; content: string }[] = [];

      if (raw.length > 0) {
        const normalized = normalizeMcqPaste(raw);
        const result = parseMCQText(normalized);
        const ts = Date.now();
        parsed = (result?.questions || []).map((q: any, i: number) => ({
          id: `mcq_${ts}_${i}_${Math.random().toString(36).slice(2)}`,
          questionNumber: q.questionNumber,
          question: (q.question || '').replace(/<br\/?>/g, '\n').replace(/^Q?\s*\d+[.)]\s*/i, '').trim(),
          options: (q.options || ['', '', '', '']).slice(0, 4),
          correctAnswer: q.correctAnswer ?? 0,
          statements: (q.statements && q.statements.length > 0) ? q.statements : undefined,
          matchColumns: q.matchColumns || undefined,
          passage: (q.passage || '').trim() || undefined,
          questionType: q.questionType || (q.matchColumns ? 'MATCH_COLUMN' : undefined),
          topic: (q.topic || '').trim() || undefined,
          explanation: (q.explanation || '').trim() || undefined,
          concept: (q.concept || '').trim() || undefined,
          examTip: (q.examTip || '').trim() || undefined,
          difficultyLevel: q.difficultyLevel || undefined,
        }));
        if (!parsed.length) {
          showAlert('❌ Parse nahi hua. Format: <TOPIC: naam>\nQ1. sawaal?\nA) opt\nAnswer: B) text');
          setSaving(false); return;
        }

        // Save <NOTE: ...> blocks
        const noteRegex = /<NOTE:\s*([^>]+)>([\s\S]*?)<\/NOTE[^>]*>/gi;
        let m: RegExpExecArray | null;
        while ((m = noteRegex.exec(raw)) !== null) {
          const title = m[1].trim(); const content = m[2].trim();
          if (title && content) notesToSave.push({ title, content });
        }
        if (notesToSave.length) saveTopicNotes(notesToSave);
      }

      const lessonId = editingLesson ? editingLesson.id : `lesson_${Date.now()}_${Math.random().toString(36).slice(2)}`;

      // Merge topicNotes: keep existing + add new ones (dedup by title)
      const existingNotes: { title: string; content: string }[] = editingLesson?.topicNotes || [];
      const mergedNotes = [...existingNotes];
      for (const n of notesToSave) {
        const idx = mergedNotes.findIndex(e => e.title.trim().toLowerCase() === n.title.trim().toLowerCase());
        if (idx >= 0) mergedNotes[idx] = n;
        else mergedNotes.push(n);
      }

      const existingMcqs = editingLesson ? (editingLesson.mcqs || []) : [];
      const allMcqs = [...existingMcqs, ...parsed];
      const allTopics = [...new Set(allMcqs.map((q: any) => q.topic).filter(Boolean))] as string[];

      const lesson = {
        id: lessonId,
        classLevel: editingLesson?.classLevel || selectedClass,
        subject: editingLesson?.subject || selectedSubject,
        board: editingLesson?.board ?? (boardFilter || null),
        bookName: bookName.trim() || editingLesson?.bookName || null,
        lessonTitle: lessonTitle.trim(),
        mcqs: allMcqs,
        mcqCount: allMcqs.length,
        topics: allTopics,
        topicCount: allTopics.length,
        topicNotes: mergedNotes,
        createdAt: editingLesson ? editingLesson.createdAt : new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        sourceClassNotesId: editingLesson?.sourceClassNotesId || null,
      };

      await saveMcqLesson(lesson);
      const noteMsg = notesToSave.length ? ` + ${notesToSave.length} note(s)` : '';
      const mcqMsg = parsed.length > 0 ? `✅ ${parsed.length} MCQ save ho gaye! ` : (editingLesson ? '✅ Lesson update ho gaya! ' : '✅ Naya Lesson create ho gaya! ');
      showAlert(`${mcqMsg}Lesson: "${lessonTitle.trim()}"${noteMsg}`);
      setPasteText('');
      if (!editingLesson) { setLessonTitle(''); setBookName(''); }
      setScreen('LESSON_LIST');
      setEditingLesson(null);
    } catch (err: any) {
      showAlert(`❌ Error: ${err?.message || 'Save nahi hua'}`);
    }
    setSaving(false);
  };

  const handleDeleteLesson = async (lesson: any) => {
    if (!confirm(`"${lesson.lessonTitle}" permanently delete karein?\n${lesson.mcqCount} MCQs hamesha ke liye chale jayenge.`)) return;
    try {
      await deleteMcqLesson(lesson.id);
      showAlert(`🗑️ "${lesson.lessonTitle}" delete ho gaya`);
    } catch (err: any) {
      showAlert(`❌ Delete failed: ${err?.message || ''}`);
    }
  };

  const handleDeleteSingleMcq = async (lesson: any, mcqIdx: number) => {
    if (!confirm(`Q${mcqIdx + 1} delete karein?`)) return;
    const newMcqs = lesson.mcqs.filter((_: any, i: number) => i !== mcqIdx);
    const topics = [...new Set(newMcqs.map((q: any) => q.topic).filter(Boolean))] as string[];
    const updated = { ...lesson, mcqs: newMcqs, mcqCount: newMcqs.length, topics, topicCount: topics.length, updatedAt: new Date().toISOString() };
    await saveMcqLesson(updated);
    showAlert(`✅ Q${mcqIdx + 1} delete ho gaya. Remaining: ${newMcqs.length}`);
  };

  const openMoveCopy = (lesson: any, mode: 'move' | 'copy') => {
    const defaultClass = CLASSES.filter(c => c !== lesson.classLevel)[0] || '6';
    setMcTargetClass(defaultClass);
    setMcTargetSubject(subjectsForClass(defaultClass, settings)[0] || '');
    setMcTargetBoard(lesson.board || '');
    setMoveCopyModal({ lesson, mode });
  };

  const handleConfirmMoveCopy = async () => {
    if (!moveCopyModal || !mcTargetClass || !mcTargetSubject) return;
    const { lesson, mode } = moveCopyModal;
    setMcWorking(true);
    try {
      const ts = Date.now();
      const newId = `lesson_${ts}_${Math.random().toString(36).slice(2)}`;
      const newLesson = {
        ...lesson,
        id: newId,
        classLevel: mcTargetClass,
        subject: mcTargetSubject,
        board: mcTargetBoard || null,
        updatedAt: new Date().toISOString(),
      };
      await saveMcqLesson(newLesson);
      const boardLabel = mcTargetBoard ? ` / ${BOARD_OPTIONS.find(b => b.id === mcTargetBoard)?.label ?? mcTargetBoard}` : '';
      if (mode === 'move') {
        await deleteMcqLesson(lesson.id);
        showAlert(`✅ "${lesson.lessonTitle}" move ho gaya → Class ${mcTargetClass} / ${mcTargetSubject}${boardLabel}`);
      } else {
        showAlert(`✅ "${lesson.lessonTitle}" copy ho gaya → Class ${mcTargetClass} / ${mcTargetSubject}${boardLabel}`);
      }
      setMoveCopyModal(null);
    } catch (err: any) {
      showAlert(`❌ Error: ${err?.message || 'Failed'}`);
    }
    setMcWorking(false);
  };

  const goBack = () => {
    if (screen === 'ADD_LESSON')  { setScreen('LESSON_LIST'); setLessonTitle(''); setBookName(''); setPasteText(''); setEditingLesson(null); return; }
    if (screen === 'LESSON_LIST') { setScreen('SUBJECT'); setSelectedSubject(null); return; }
    if (screen === 'SUBJECT')     { setScreen('CLASS'); setSelectedClass(null); return; }
  };

  // ── Screen: CLASS ────────────────────────────────────────────────────────────
  if (screen === 'CLASS') return (
    <div className="space-y-3 p-4">
      {BoardBar}
      <p className="text-xs font-bold text-slate-500 uppercase mb-3">Class Choose Karein</p>
      <div className="grid grid-cols-4 gap-2">
        {CLASSES.filter(c => c !== 'COMPETITION').map(c => {
          const cnt = lessonCountForClass(c);
          return (
            <button key={c} onClick={() => { setSelectedClass(c); setScreen('SUBJECT'); }}
              className="flex flex-col items-center p-3 rounded-2xl border-2 border-indigo-100 bg-indigo-50 active:scale-95 transition-all"
            >
              <span className="text-xl mb-1">📚</span>
              <span className="text-[9px] text-slate-400 font-bold">CLASS</span>
              <span className="text-lg font-black text-indigo-700">{c}</span>
              {cnt > 0 && (
                <span className="text-[7px] mt-0.5 bg-indigo-200 text-indigo-700 font-bold px-1.5 py-0.5 rounded-full">
                  {cnt} lessons
                </span>
              )}
            </button>
          );
        })}
      </div>
      <button onClick={() => { setSelectedClass('COMPETITION'); setScreen('SUBJECT'); }}
        className="w-full flex items-center gap-3 p-3.5 rounded-2xl border-2 border-amber-200 bg-amber-50 active:scale-95 transition-all"
      >
        <span className="text-2xl">🏆</span>
        <div className="flex-1 text-left">
          <p className="font-black text-slate-800">Competition / Govt. Exams</p>
          <p className="text-[10px] text-slate-500">SSC · UPSC · Railway · Police</p>
        </div>
        <span className="text-[10px] bg-amber-100 text-amber-700 font-bold px-2 py-0.5 rounded-full mr-2">
          {lessonCountForClass('COMPETITION')} lessons
        </span>
        <ChevronRight size={16} className="text-amber-500" />
      </button>

      {/* Sync All Notes to Revision Hub button */}
      <div className="pt-2">
        <button
          onClick={handleSyncAllNotes}
          disabled={syncingAllNotes}
          className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl border border-indigo-200 bg-indigo-50 text-indigo-700 text-xs font-bold hover:bg-indigo-100 active:scale-95 transition-all disabled:opacity-50 shadow-sm"
        >
          <span className={syncingAllNotes ? 'animate-spin' : ''}>🔄</span>
          {syncingAllNotes ? 'Notes sync ho rahe hain...' : 'Sync All Admin Notes to Revision Hub'}
        </button>
        <p className="text-[10px] text-slate-400 text-center mt-1">Admin Dashboard ke sabhi notes ko Revision Hub lessons me sync karein.</p>
      </div>
    </div>
  );

  // ── Screen: SUBJECT ───────────────────────────────────────────────────────────
  if (screen === 'SUBJECT') return (
    <div className="space-y-2 p-4">
      {BoardBar}
      <button onClick={goBack} className="flex items-center gap-1 text-xs text-indigo-600 font-bold mb-3">
        <ArrowLeft size={14} /> Back to Classes
      </button>

      {(selectedClass === '10' || selectedClass === '12') && (
        <div className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-300 text-xs space-y-1.5 mb-3 shadow-xs">
          <div className="font-black text-emerald-800 flex items-center gap-1.5">
            <span>⚡ ऑटो-प्रैक्टिस सेट व साप्ताहिक लीडरबोर्ड (Automated Sets & Ranking)</span>
          </div>
          <p className="text-[11px] text-slate-700 leading-relaxed">
            कक्षा {selectedClass} में सेट्स मैन्युअल बनाने की आवश्यकता नहीं है। आप सिर्फ विषय में प्रश्न जोड़ते जाएं—सिस्टम 25-25 प्रश्नों के <strong>सेट 1, सेट 2, सेट 3...</strong> अपने-आप तैयार कर देता है। <strong>सभी छात्रों का सेट 1 बिल्कुल समान रहेगा</strong> और हर सेट का <strong>साप्ताहिक लीडरबोर्ड</strong> प्रत्येक हफ्ते रविवार को अपडेट होता रहेगा!
          </p>
        </div>
      )}

      <p className="text-xs font-bold text-slate-500 uppercase mb-2">Class {selectedClass} — Subject Choose Karein</p>
      {subjectsList.map(sub => {
        const cnt = lessonCountForSubject(selectedClass!, sub);
        return (
          <button key={sub} onClick={() => { setSelectedSubject(sub); setScreen('LESSON_LIST'); }}
            className="w-full flex items-center justify-between px-4 py-3 rounded-xl border border-slate-200 bg-white active:scale-[0.99] transition-all shadow-sm"
          >
            <span className="font-bold text-slate-800">{sub}</span>
            <div className="flex items-center gap-2">
              {cnt > 0 && (
                <span className="text-[10px] bg-indigo-100 text-indigo-700 font-bold px-2 py-0.5 rounded-full">
                  {cnt} lessons
                </span>
              )}
              <ChevronRight size={14} className="text-slate-400" />
            </div>
          </button>
        );
      })}
    </div>
  );

  // ── Screen: LESSON LIST ───────────────────────────────────────────────────────
  if (screen === 'LESSON_LIST') return (
    <div className="p-4 space-y-4">
      {BoardBar}
      <div className="flex items-center gap-2">
        <button onClick={goBack} className="flex items-center gap-1 text-xs text-indigo-600 font-bold">
          <ArrowLeft size={14} /> Back
        </button>
        <span className="text-xs text-slate-400 flex-1">Class {selectedClass} → {selectedSubject}</span>
        <button onClick={() => { setEditingLesson(null); setLessonTitle(''); setBookName(''); setPasteText(''); setScreen('ADD_LESSON'); }}
          className="flex items-center gap-1.5 bg-indigo-600 text-white text-xs font-bold px-3 py-1.5 rounded-xl active:scale-95 transition-all"
        >
          <Plus size={13} /> New Lesson
        </button>
      </div>

      {alert && (
        <div className="p-2.5 rounded-xl bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-bold">{alert}</div>
      )}

      {filteredLessons.length === 0 ? (
        <div className="text-center py-12">
          <div className="text-4xl mb-3">📭</div>
          <p className="text-slate-600 font-bold">Koi lesson nahi abhi</p>
          <p className="text-slate-400 text-sm mt-1">+ New Lesson button se pehla lesson add karein</p>
        </div>
      ) : (() => {
        // Group lessons by bookName
        const bookGroups: { bookName: string | null; lessons: any[] }[] = [];
        const seen = new Map<string, number>();
        for (const lesson of filteredLessons) {
          const key = lesson.bookName || '';
          if (seen.has(key)) {
            bookGroups[seen.get(key)!].lessons.push(lesson);
          } else {
            seen.set(key, bookGroups.length);
            bookGroups.push({ bookName: lesson.bookName || null, lessons: [lesson] });
          }
        }
        const hasBooks = bookGroups.some(g => g.bookName);
        return (
          <div className="space-y-4">
            {bookGroups.map((group, gi) => (
              <div key={gi}>
                {hasBooks && (
                  <div className="flex items-center gap-2 mb-2">
                    <Library size={13} className="text-emerald-600 shrink-0" />
                    <span className="text-[11px] font-black text-emerald-700 uppercase tracking-wide">
                      {group.bookName || '📂 No Book'}
                    </span>
                    <span className="text-[9px] bg-emerald-100 text-emerald-700 font-bold px-1.5 py-0.5 rounded-full">
                      {group.lessons.length} lesson{group.lessons.length !== 1 ? 's' : ''}
                    </span>
                  </div>
                )}
                <div className="space-y-3">
                  {group.lessons.map((lesson: any) => (
                    <LessonCard
                      key={lesson.id}
                      lesson={lesson}
                      onEdit={() => { setEditingLesson(lesson); setLessonTitle(lesson.lessonTitle); setBookName(lesson.bookName || ''); setPasteText(''); setScreen('ADD_LESSON'); }}
                      onDelete={() => handleDeleteLesson(lesson)}
                      onDeleteMcq={(idx) => handleDeleteSingleMcq(lesson, idx)}
                      onMove={() => openMoveCopy(lesson, 'move')}
                      onCopy={() => openMoveCopy(lesson, 'copy')}
                    />
                  ))}
                </div>
              </div>
            ))}
          </div>
        );
      })()}

      {/* ── Move / Copy Modal ───────────────────────────────────────────── */}
      {moveCopyModal && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/40 p-4">
          <div className="w-full max-w-sm bg-white rounded-2xl shadow-2xl p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-black text-slate-800 text-base">
                {moveCopyModal.mode === 'move' ? '➡️ Lesson Move Karein' : '📋 Lesson Copy Karein'}
              </h3>
              <button onClick={() => setMoveCopyModal(null)} className="p-1 rounded-lg bg-slate-100 text-slate-500 active:scale-95">
                <X size={15} />
              </button>
            </div>

            <div className="px-3 py-2 bg-indigo-50 rounded-xl text-xs text-indigo-700 font-bold truncate">
              "{moveCopyModal.lesson.lessonTitle}" ({moveCopyModal.lesson.mcqCount} MCQs)
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-500 uppercase">Target Class</label>
              <div className="grid grid-cols-4 gap-1.5">
                {CLASSES.filter(c => c !== 'COMPETITION').map(c => (
                  <button
                    key={c}
                    onClick={() => {
                      setMcTargetClass(c);
                      setMcTargetSubject(subjectsForClass(c, settings)[0] || '');
                    }}
                    className={`py-2 rounded-xl text-xs font-black transition-all active:scale-95 ${
                      mcTargetClass === c
                        ? 'bg-indigo-600 text-white'
                        : 'bg-indigo-50 text-indigo-700 border border-indigo-100'
                    }`}
                  >
                    {c}
                  </button>
                ))}
                <button
                  onClick={() => {
                    setMcTargetClass('COMPETITION');
                    setMcTargetSubject(subjectsForClass('COMPETITION', settings)[0] || '');
                  }}
                  className={`col-span-4 py-2 rounded-xl text-xs font-black transition-all active:scale-95 ${
                    mcTargetClass === 'COMPETITION'
                      ? 'bg-amber-500 text-white'
                      : 'bg-amber-50 text-amber-700 border border-amber-100'
                  }`}
                >
                  🏆 Competition
                </button>
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-500 uppercase">Target Subject</label>
              <select
                value={mcTargetSubject}
                onChange={e => setMcTargetSubject(e.target.value)}
                className="w-full p-2.5 border border-slate-200 rounded-xl text-sm font-bold text-slate-700 outline-none focus:border-indigo-400 bg-white"
              >
                {subjectsForClass(mcTargetClass, settings).map(sub => (
                  <option key={sub} value={sub}>{sub}</option>
                ))}
              </select>
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-500 uppercase">Target Board</label>
              <div className="grid grid-cols-2 gap-1.5">
                {BOARD_OPTIONS.map(b => (
                  <button
                    key={b.id}
                    type="button"
                    onClick={() => setMcTargetBoard(b.id as '' | 'NCERT_EN' | 'NCERT_HI' | 'BSEB')}
                    className={`py-2 rounded-xl text-[11px] font-black transition-all active:scale-95 ${
                      mcTargetBoard === b.id
                        ? 'bg-indigo-600 text-white shadow'
                        : 'bg-indigo-50 text-indigo-700 border border-indigo-100'
                    }`}
                  >
                    {b.label}
                  </button>
                ))}
              </div>
            </div>

            {moveCopyModal.mode === 'move' && (
              <p className="text-[10px] text-rose-500 font-bold bg-rose-50 px-3 py-2 rounded-xl">
                ⚠️ Move karne ke baad yeh lesson current class se hat jayega.
              </p>
            )}

            <button
              onClick={handleConfirmMoveCopy}
              disabled={mcWorking || !mcTargetSubject}
              className={`w-full py-3 rounded-xl font-black text-white text-sm flex items-center justify-center gap-2 active:scale-95 transition-all disabled:opacity-50 ${
                moveCopyModal.mode === 'move' ? 'bg-indigo-600' : 'bg-emerald-600'
              }`}
            >
              {moveCopyModal.mode === 'move' ? <ArrowRight size={15} /> : <Copy size={15} />}
              {mcWorking
                ? (moveCopyModal.mode === 'move' ? 'Moving...' : 'Copying...')
                : (moveCopyModal.mode === 'move'
                    ? `Move → Class ${mcTargetClass}`
                    : `Copy → Class ${mcTargetClass}`)}
            </button>
          </div>
        </div>
      )}
    </div>
  );

  // ── Screen: ADD / EDIT LESSON ─────────────────────────────────────────────────
  return (
    <div className="p-4 space-y-4">
      <div className="flex items-center gap-2">
        <button onClick={goBack} className="flex items-center gap-1 text-xs text-indigo-600 font-bold">
          <ArrowLeft size={14} /> Back
        </button>
        <span className="text-xs text-slate-400">{selectedClass} → {selectedSubject}</span>
        {boardFilter && (
          <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-700">
            {BOARD_OPTIONS.find(b => b.id === boardFilter)?.label}
          </span>
        )}
        <span className="ml-auto text-xs font-black text-indigo-600">
          {editingLesson ? `Edit: ${editingLesson.lessonTitle}` : 'New Lesson'}
        </span>
      </div>

      {alert && (
        <div className="p-2.5 rounded-xl bg-indigo-50 border border-indigo-200 text-indigo-700 text-xs font-bold">{alert}</div>
      )}

      {/* Book Name */}
      <div>
        <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1 flex items-center gap-1">
          <Library size={11} className="text-emerald-600" /> Book / Textbook Name <span className="text-slate-400 font-normal normal-case">(optional)</span>
        </label>
        <input
          type="text"
          value={bookName}
          onChange={e => setBookName(e.target.value)}
          placeholder="e.g. NCERT Physics Part 1, RD Sharma, HC Verma..."
          className="w-full p-2.5 border border-slate-200 rounded-xl text-sm outline-none focus:border-emerald-400"
        />
      </div>

      {/* Lesson Title */}
      <div>
        <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">
          Lesson / Chapter Title <span className="text-rose-500">*</span>
        </label>
        <input
          type="text"
          value={lessonTitle}
          onChange={e => setLessonTitle(e.target.value)}
          placeholder="e.g. Chapter 6 — पोषण (Nutrition)"
          className="w-full p-2.5 border border-slate-200 rounded-xl text-sm outline-none focus:border-indigo-400"
        />
      </div>

      {/* Editing: show existing MCQ count */}
      {editingLesson && (
        <div className="flex items-center gap-2 px-3 py-2 bg-violet-50 border border-violet-200 rounded-xl text-xs text-violet-700 font-bold">
          <BookOpen size={14} />
          <span>Already saved: {editingLesson.mcqCount} MCQs · Niche paste karke aur add karein</span>
        </div>
      )}

      {/* Format hint */}
      <div className="rounded-xl bg-slate-50 border border-slate-200 p-3">
        <p className="text-[10px] font-bold text-slate-500 uppercase mb-1.5">Format Example</p>
        <pre className="text-[9.5px] text-slate-600 whitespace-pre-wrap font-mono leading-relaxed">{`<TOPIC: पोषण (Nutrition)>

Q1. Bharat ki rajdhani kya hai?
A) Mumbai
B) New Delhi
C) Chennai
D) Kolkata
Answer: B) New Delhi
Explanation: New Delhi Bharat ki rajdhani hai.

<TOPIC: Digestive System>

Q2. Paani ka formula?
A) CO2
B) H2O
C) NaCl
D) O2
Answer: B) H2O`}</pre>
      </div>

      {/* MCQ Paste */}
      <div>
        <label className="text-[10px] font-bold text-slate-500 uppercase block mb-1">
          MCQ Paste Karein <span className="text-rose-500">*</span>
        </label>
        <textarea
          value={pasteText}
          onChange={e => setPasteText(e.target.value)}
          placeholder="Yahan MCQ paste karein... ChatGPT/Gemini output ya simple format — dono chalega&#10;&#10;Ek lesson mein multiple topics ho sakte hain: <TOPIC: naam> use karein"
          className="w-full p-3 border border-slate-200 rounded-xl text-sm outline-none h-48 focus:border-indigo-400 font-mono resize-none"
        />
      </div>

      <button
        onClick={handleSaveLesson}
        disabled={saving || !pasteText.trim() || !lessonTitle.trim()}
        className="w-full bg-indigo-600 disabled:bg-slate-300 text-white py-3.5 rounded-xl font-bold flex items-center justify-center gap-2 active:scale-95 transition-all"
      >
        <Save size={16} />
        {saving ? 'Saving...' : editingLesson ? 'MCQs Add Karo Is Lesson Mein' : 'Lesson Save Karo'}
      </button>
    </div>
  );
};

// ── Helper: extract statements from question text (fallback for old MCQs) ─────
const ADMIN_STMT_RE = /^(?:\d+[.)]\s+|(?:Statement|कथन|Assertion|Reason)\s*\d*\s*[:.\-)]\s*|[IVX]+[.)]\s+).+/i;

function extractAdminStatements(q: any): { stem: string; stmts: string[]; suffix: string } {
  // If statements already stored, use them
  if (q.statements && q.statements.length > 0) {
    return { stem: (q.question || '').replace(/<br\/?>/g, ' ').trim(), stmts: q.statements, suffix: '' };
  }
  // Auto-extract from question text (for old MCQs)
  const raw = (q.question || '').replace(/<br\s*\/?>/gi, '\n');
  const lines = raw.split('\n').map((l: string) => l.trim()).filter(Boolean);
  const preLines: string[] = [], stmtLines: string[] = [], suffixLines: string[] = [];
  let phase: 'pre' | 'stmts' | 'suffix' = 'pre';
  for (const line of lines) {
    if (phase === 'pre') {
      if (ADMIN_STMT_RE.test(line)) { phase = 'stmts'; stmtLines.push(line); }
      else preLines.push(line);
    } else if (phase === 'stmts') {
      if (ADMIN_STMT_RE.test(line)) stmtLines.push(line);
      else { phase = 'suffix'; suffixLines.push(line); }
    } else suffixLines.push(line);
  }
  return {
    stem: stmtLines.length > 0 ? preLines.join(' ') : lines.join(' '),
    stmts: stmtLines,
    suffix: suffixLines.join(' '),
  };
}

// ── Lesson Card component ─────────────────────────────────────────────────────
function LessonCard({ lesson, onEdit, onDelete, onDeleteMcq, onMove, onCopy }: {
  lesson: any;
  onEdit: () => void;
  onDelete: () => void;
  onDeleteMcq: (idx: number) => void;
  onMove: () => void;
  onCopy: () => void;
}) {
  const [expanded, setExpanded] = useState(false);

  return (
    <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
      {/* Header */}
      <div className="px-4 py-3 flex items-start gap-3">
        <div onClick={onEdit} className="w-10 h-10 rounded-xl bg-indigo-50 flex items-center justify-center shrink-0 cursor-pointer hover:bg-indigo-100 transition-colors" title="Click to add MCQs">
          <BookOpen size={18} className="text-indigo-600" />
        </div>
        <div onClick={onEdit} className="flex-1 min-w-0 cursor-pointer group">
          {lesson.bookName && (
            <div className="flex items-center gap-1 mb-0.5">
              <Library size={9} className="text-emerald-600 shrink-0" />
              <span className="text-[9px] font-bold text-emerald-700 truncate">{lesson.bookName}</span>
            </div>
          )}
          <p className="font-black text-slate-800 text-sm truncate group-hover:text-indigo-600 transition-colors">{lesson.lessonTitle}</p>
          <div className="flex flex-wrap gap-1 mt-1">
            <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full ${lesson.mcqCount > 0 ? 'bg-indigo-100 text-indigo-700' : 'bg-amber-100 text-amber-700'}`}>
              {lesson.mcqCount > 0 ? `${lesson.mcqCount} MCQs` : '0 MCQs · Click to Add MCQs'}
            </span>
            {(lesson.topics || []).slice(0, 3).map((t: string) => (
              <span key={t} className="text-[9px] font-bold bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded-full truncate max-w-[100px]">
                {t}
              </span>
            ))}
            {(lesson.topics || []).length > 3 && (
              <span className="text-[9px] font-bold bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded-full">
                +{lesson.topics.length - 3} more
              </span>
            )}
          </div>
        </div>
        <div className="flex items-center gap-1 shrink-0">
          <button onClick={onEdit} className="p-1.5 rounded-lg bg-violet-50 text-violet-600 active:scale-95 transition-all" title="MCQs add karein">
            <Edit2 size={13} />
          </button>
          <button onClick={onMove} className="p-1.5 rounded-lg bg-blue-50 text-blue-600 active:scale-95 transition-all" title="Dusri class mein move karein">
            <ArrowRight size={13} />
          </button>
          <button onClick={onCopy} className="p-1.5 rounded-lg bg-emerald-50 text-emerald-600 active:scale-95 transition-all" title="Dusri class mein copy karein">
            <Copy size={13} />
          </button>
          <button onClick={onDelete} className="p-1.5 rounded-lg bg-rose-50 text-rose-500 active:scale-95 transition-all" title="Delete lesson">
            <Trash2 size={13} />
          </button>
          <button onClick={() => setExpanded(!expanded)}
            className={`p-1.5 rounded-lg transition-all active:scale-95 ${expanded ? 'bg-slate-200 text-slate-700' : 'bg-slate-100 text-slate-500'}`}
          >
            <ChevronRight size={14} className={`transition-transform ${expanded ? 'rotate-90' : ''}`} />
          </button>
        </div>
      </div>

      {/* Expanded MCQ list */}
      {expanded && (
        <div className="border-t border-slate-100 bg-slate-50 px-3 py-2 max-h-72 overflow-y-auto">
          {(lesson.mcqs || []).map((q: any, qi: number) => {
            const { stem, stmts, suffix } = extractAdminStatements(q);
            return (
            <div key={qi} className="flex items-start gap-2 py-2 border-b border-slate-100 last:border-0">
              <span className="text-[9px] font-black text-slate-400 shrink-0 mt-0.5">Q{qi + 1}</span>
              <div className="flex-1 min-w-0">
                {q.topic && (
                  <span className="text-[8px] font-bold bg-indigo-100 text-indigo-600 px-1 py-0.5 rounded mr-1">{q.topic}</span>
                )}
                <p className="text-[10px] text-slate-700 font-medium leading-relaxed line-clamp-2">
                  {stem || (q.question || '').replace(/<br\/?>/g, ' ')}
                </p>
                {q.matchColumns && q.matchColumns.rows && q.matchColumns.rows.length > 0 ? (
                  <div className="mt-1 grid grid-cols-2 gap-1 text-[9px]">
                    <div className="p-1.5 rounded-lg bg-indigo-50 border border-indigo-200">
                      <span className="font-bold text-indigo-700 block mb-0.5">{q.matchColumns.list1Title || "खण्ड 'अ' (सूची-I)"}</span>
                      {q.matchColumns.rows.map((r: any, ri: number) => (
                        <div key={ri} className="truncate text-slate-700">
                          <b className="text-indigo-600">{r.leftKey || String.fromCharCode(97 + ri)}.</b> {r.leftText}
                        </div>
                      ))}
                    </div>
                    <div className="p-1.5 rounded-lg bg-emerald-50 border border-emerald-200">
                      <span className="font-bold text-emerald-700 block mb-0.5">{q.matchColumns.list2Title || "खण्ड 'ब' (सूची-II)"}</span>
                      {q.matchColumns.rows.map((r: any, ri: number) => (
                        <div key={ri} className="truncate text-slate-700">
                          <b className="text-emerald-600">{r.rightKey || String(ri + 1)}.</b> {r.rightText}
                        </div>
                      ))}
                    </div>
                  </div>
                ) : stmts.length > 0 ? (
                  <div className="mt-1 flex flex-col gap-0.5">
                    {stmts.map((s: string, si: number) => (
                      <div key={si} className="text-[9px] text-indigo-700 bg-indigo-50 border-l-2 border-indigo-300 px-1.5 py-0.5 rounded-r font-medium">
                        {s}
                      </div>
                    ))}
                    {suffix && (
                      <p className="text-[9px] text-slate-600 font-medium mt-0.5">{suffix}</p>
                    )}
                  </div>
                ) : null}
                <p className="text-[9px] text-emerald-700 font-bold mt-0.5">
                  ✓ {String.fromCharCode(65 + q.correctAnswer)}. {q.options?.[q.correctAnswer] || ''}
                </p>
              </div>
              <button onClick={() => onDeleteMcq(qi)} className="text-rose-300 hover:text-rose-500 shrink-0 active:scale-95 transition-all p-0.5">
                <X size={11} />
              </button>
            </div>
          ); })}
        </div>
      )}
    </div>
  );
}

// @ts-nocheck
import React, { useState } from "react";
import { UserPlus, X, Save, User, Phone, Calendar, Image as ImageIcon, CheckCircle2 } from "lucide-react";
import { DirectUploadButton } from "../DirectUploadButton";
import { saveStudent, generateId, generateNextAdmissionNo, saveSchoolUserProfile, getLocalStudents, setLocalStudents } from "../../school-firebase";
import { saveUserToLive } from "../../firebase";
import type { School, SchoolClass, SchoolStudent, SeniorStream } from "../../school-types";
import {
  BLOOD_GROUPS,
  SENIOR_STREAMS,
  isSeniorClass,
  sortSchoolClasses,
  getDefaultSubjectsForClass,
} from "../../school-types";

interface Props {
  isOpen: boolean;
  onClose: () => void;
  schoolId: string;
  classes: SchoolClass[];
  defaultClassId?: string;
  onStudentAdded: (student: SchoolStudent) => void;
}

export const QuickAddStudentModal: React.FC<Props> = ({
  isOpen,
  onClose,
  schoolId,
  classes,
  defaultClassId,
  onStudentAdded,
}) => {
  const sortedClasses = React.useMemo(() => sortSchoolClasses(classes), [classes]);
  const initialCls = sortedClasses.find(c => c.id === defaultClassId) || sortedClasses[0];
  const [classId, setClassId] = useState<string>(defaultClassId || sortedClasses[0]?.id || "");
  const [stream, setStream] = useState<SeniorStream>("Science");
  const selectedCls = React.useMemo(() => sortedClasses.find(c => c.id === classId) || null, [sortedClasses, classId]);

  React.useEffect(() => {
    if (selectedCls?.stream && (selectedCls.stream === "Science" || selectedCls.stream === "Commerce" || selectedCls.stream === "Arts")) {
      setStream(selectedCls.stream as SeniorStream);
    }
  }, [selectedCls]);

  const [name, setName] = useState("");
  const [rollNo, setRollNo] = useState("");
  const [admissionNo, setAdmissionNo] = useState(() =>
    generateNextAdmissionNo({ id: schoolId, code: schoolId.slice(0, 4) }, getLocalStudents(schoolId).length)
  );
  const [fatherName, setFatherName] = useState("");
  const [motherName, setMotherName] = useState("");
  const [phone, setPhone] = useState("");
  const [dateOfBirth, setDateOfBirth] = useState("2012-05-15");
  const [bloodGroup, setBloodGroup] = useState("");
  const [photoUrl, setPhotoUrl] = useState("");
  const [monthlyFee, setMonthlyFee] = useState<number>(() =>
    Number(initialCls?.feeStructure?.tuitionFee ?? initialCls?.defaultFee ?? 0)
  );
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError("Kripya student ka full name enter karein.");
      return;
    }
    if (!rollNo.trim()) {
      setError("Roll Number zaroori hai.");
      return;
    }

    setSaving(true);
    setError(null);
    try {
      const studentId = generateId();
      const isSenior = isSeniorClass(selectedCls?.name);
      const chosenStream = isSenior ? (selectedCls?.stream || stream) : undefined;

      const newStudent: SchoolStudent = {
        id: studentId,
        schoolId,
        sessionId: "",
        classId,
        className: selectedCls ? `${selectedCls.name}${selectedCls.section ? ` (${selectedCls.section})` : ""}` : "",
        stream: chosenStream,
        name: name.trim(),
        rollNo: rollNo.trim(),
        admissionNo: admissionNo.trim(),
        fatherName: fatherName.trim(),
        motherName: motherName.trim(),
        phone: phone.trim(),
        dateOfBirth,
        bloodGroup: bloodGroup.trim() || undefined,
        photoUrl,
        monthlyFee: Number(monthlyFee) || 0,
        active: true,
        joinDate: new Date().toISOString().split("T")[0],
        createdAt: new Date().toISOString(),
      };

      const savedStudent = await saveStudent(newStudent);

      // Register student profile strictly scoped to THIS schoolId (no cross-school copying!)
      try {
        const curLocals = getLocalStudents(schoolId);
        setLocalStudents(schoolId, [savedStudent, ...curLocals.filter(s => s.id !== savedStudent.id)]);

        const safeSchoolSlug = (schoolId || "academy").toLowerCase().replace(/[^a-z0-9]/g, "") || "academy";
        const studentEmail = `${savedStudent.admissionNo.toLowerCase().replace(/[^a-z0-9]/g, "")}@student.${safeSchoolSlug}.edu`;

        const studentUserPayload = {
          id: savedStudent.id,
          uid: savedStudent.id,
          displayId: `ROLL-${savedStudent.rollNo}`,
          name: savedStudent.name,
          email: studentEmail,
          mobile: savedStudent.phone,
          role: 'STUDENT',
          schoolId,
          classLevel: classId,
          stream: chosenStream || 'General',
          credits: 100,
          diamonds: 50,
          streak: 1,
          totalScore: 0,
          profileCompleted: true,
          subscriptionTier: 'PRO',
          provider: 'qr_student_id',
          isQrLogin: true,
          admissionNo: savedStudent.admissionNo,
          rollNo: savedStudent.rollNo,
          fatherName: savedStudent.fatherName,
          motherName: savedStudent.motherName,
          bloodGroup: savedStudent.bloodGroup,
          monthlyFee: savedStudent.monthlyFee,
        };

        saveSchoolUserProfile({
          uid: savedStudent.id,
          schoolId,
          role: 'SCHOOL_STUDENT',
          name: savedStudent.name,
          email: studentEmail,
          studentRef: savedStudent.id,
          classId,
          sessionId: '2026-27'
        }).catch(() => {});

        saveUserToLive(studentUserPayload, { immediate: true }).catch(() => {});
      } catch (e) {}

      onStudentAdded(savedStudent);
      onClose();
    } catch (err: any) {
      console.error("Failed to add student:", err);
      setError(err?.message || "Student save karne mein error aaya.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-3 sm:p-5 bg-slate-950/70 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-emerald-800 via-teal-900 to-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-emerald-300">
              <UserPlus className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-black leading-tight text-white">Naya Student Add Karein</h2>
              <p className="text-xs text-emerald-200 font-medium">Turant marksheet, admit card aur certificate banayein</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/10 text-slate-300 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 overflow-y-auto space-y-4 flex-1">
          {error && (
            <div className="p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-500/30 rounded-xl text-rose-700 dark:text-rose-300 text-xs font-bold">
              {error}
            </div>
          )}

          {/* Class & Roll */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Class / Kaksha *
              </label>
              <select
                value={classId}
                onChange={e => setClassId(e.target.value)}
                className="w-full px-3 py-2 text-xs font-bold rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-hidden"
              >
                {sortedClasses.map(c => (
                  <option key={c.id} value={c.id}>{c.name} {c.section ? `(${c.section})` : ""}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Roll Number *
              </label>
              <input
                type="text"
                required
                value={rollNo}
                onChange={e => setRollNo(e.target.value)}
                placeholder="e.g. 101"
                className="w-full px-3 py-2 text-xs font-bold rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-hidden"
              />
            </div>
          </div>

          {isSeniorClass(selectedCls?.name) && (
            <div className="p-3 bg-gradient-to-r from-emerald-50/80 to-teal-50/80 dark:from-emerald-950/40 dark:to-teal-950/30 rounded-2xl border border-emerald-200 dark:border-emerald-800 space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-black text-emerald-900 dark:text-emerald-200 flex items-center gap-1.5">
                  <span>🔬 Stream Selection (11वीं / 12वीं स्ट्रीम) *</span>
                </label>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-900 text-emerald-800 dark:text-emerald-300">
                  {selectedCls?.name}
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {SENIOR_STREAMS.map(st => {
                  const isSel = stream === st.id;
                  return (
                    <button
                      type="button"
                      key={st.id}
                      onClick={() => setStream(st.id)}
                      className={`py-1.5 px-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 cursor-pointer ${
                        isSel
                          ? "bg-emerald-600 text-white shadow-xs ring-2 ring-emerald-400"
                          : "bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700"
                      }`}
                    >
                      {st.icon} {st.id}
                    </button>
                  );
                })}
              </div>
              <p className="text-[10px] text-emerald-800 dark:text-emerald-300 bg-white/70 dark:bg-slate-900/70 p-2 rounded-xl border border-emerald-100 dark:border-emerald-900">
                <span className="font-bold">विषय (Pre-configured Subjects): </span>
                <span>
                  {getDefaultSubjectsForClass(selectedCls?.name || "Class 11", stream).join(", ")}
                </span>
              </p>
            </div>
          )}

          {/* Student Full Name & Adm No */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Student Full Name *
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="e.g. Aman Kumar Sharma"
                className="w-full px-3 py-2 text-xs font-bold rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-hidden"
              />
            </div>
            <div>
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Admission / Reg Number
              </label>
              <input
                type="text"
                value={admissionNo}
                onChange={e => setAdmissionNo(e.target.value)}
                placeholder="e.g. ADM-101"
                className="w-full px-3 py-2 text-xs font-mono font-bold rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-hidden"
              />
            </div>
          </div>

          {/* Father & Mother Name */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Father's Name
              </label>
              <input
                type="text"
                value={fatherName}
                onChange={e => setFatherName(e.target.value)}
                placeholder="Shri Rajesh Sharma"
                className="w-full px-3 py-2 text-xs font-medium rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-hidden"
              />
            </div>
            <div>
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Mother's Name
              </label>
              <input
                type="text"
                value={motherName}
                onChange={e => setMotherName(e.target.value)}
                placeholder="Smt. Geeta Devi"
                className="w-full px-3 py-2 text-xs font-medium rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-hidden"
              />
            </div>
          </div>

          {/* Phone, Date of Birth & Blood Group */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Guardian Phone
              </label>
              <input
                type="tel"
                value={phone}
                onChange={e => setPhone(e.target.value)}
                placeholder="9876543210"
                className="w-full px-3 py-2 text-xs font-medium rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-hidden"
              />
            </div>
            <div>
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-1">
                Date of Birth
              </label>
              <input
                type="date"
                value={dateOfBirth}
                onChange={e => setDateOfBirth(e.target.value)}
                className="w-full px-3 py-2 text-xs font-medium rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-hidden"
              />
            </div>
            <div>
              <label className="text-xs font-bold text-rose-600 dark:text-rose-400 block mb-1">
                🩸 Blood Group
              </label>
              <select
                value={bloodGroup}
                onChange={e => setBloodGroup(e.target.value)}
                className="w-full px-3 py-2 text-xs font-bold rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-hidden"
              >
                <option value="">Select (Optional)</option>
                {BLOOD_GROUPS.map(bg => (
                  <option key={bg} value={bg}>{bg}</option>
                ))}
              </select>
            </div>
          </div>

          {/* Student Photo */}
          <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-2xl border border-slate-200 dark:border-slate-700 flex items-center gap-3">
            <div className="w-14 h-16 rounded-xl bg-white dark:bg-slate-700 border-2 border-emerald-200 dark:border-slate-600 overflow-hidden flex items-center justify-center shrink-0">
              {photoUrl ? (
                <img src={photoUrl} alt="Student" className="w-full h-full object-cover" />
              ) : (
                <User className="w-6 h-6 text-slate-400" />
              )}
            </div>
            <div className="flex-1 min-w-0 space-y-1">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 block">
                Student Photo (Upload ya link):
              </label>
              <div className="flex items-center gap-2 flex-wrap">
                <DirectUploadButton
                  kind="image"
                  compact
                  currentUrl={photoUrl}
                  onUploaded={url => setPhotoUrl(url)}
                  onClear={() => setPhotoUrl("")}
                  label="Upload Photo"
                />
                <input
                  type="text"
                  value={photoUrl}
                  onChange={e => setPhotoUrl(e.target.value)}
                  placeholder="Photo image URL..."
                  className="flex-1 min-w-[140px] px-2.5 py-1 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-800 dark:text-white"
                />
              </div>
            </div>
          </div>

          {/* Submit Buttons */}
          <div className="pt-2 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={saving}
              className="px-6 py-2.5 rounded-xl text-xs font-black bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md shadow-emerald-500/20 active:scale-95 transition flex items-center gap-1.5"
            >
              <Save className="w-4 h-4" />
              <span>{saving ? "Saving..." : "✓ Student Save & Select Karein"}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
